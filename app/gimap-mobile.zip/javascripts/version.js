window.smargeomobileversion = "1.2.2";
//window.smargeomobilebuild = "rc0";
